Meow Match Sanctuary - Bodhi Industries Edition
---------------------------------------------------

Featuring Piper (Calico Mix) & Bodacious (Maine Coon)

HOW TO PLAY / HOST:
1. Offline Play: Double-click index.html in any modern browser (Chrome, Safari, Edge, Firefox).
2. Itch.io: Upload meow-match-html-bundle.zip as an HTML5 game. Mark "This file will be played in the browser".
3. Netlify / Vercel / GitHub Pages: Drag and drop or push the extracted contents.

Published by Bodhi Industries.
